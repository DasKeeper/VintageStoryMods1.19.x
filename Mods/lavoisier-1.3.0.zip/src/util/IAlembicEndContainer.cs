﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vintagestory.API.Client;
using Vintagestory.API.Config;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;
using Vintagestory.GameContent;
using Vintagestory.API.Datastructures;

namespace lavoisier
{
    public interface IAlembicEndContainer
    {
        bool handleRecipe(RetortRecipe recipe);

        string getCustomItem();

        void stopDistilling();

        bool checkStoechiometry(RetortRecipe recipe);
    }
}
