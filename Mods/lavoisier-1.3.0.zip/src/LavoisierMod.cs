﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.GameContent;

namespace lavoisier
{
    class LavoisierMod : ModSystem
    {
        private readonly Harmony harmony = new Harmony("fr.mobydick.lavoisier");

        public override void Start(ICoreAPI api)
        {
            base.Start(api);

            api.RegisterBlockClass("AlembicBoilingFlask", typeof(AlembicBoilingFlask));
            api.RegisterBlockEntityClass("AlembicBoilingFlaskEntity", typeof(AlembicBoilingFlaskEntity));
            api.RegisterBlockClass("AlembicRetortNeck", typeof(AlembicRetortNeck));
            api.RegisterBlockEntityClass("AlembicRetortNeckEntity", typeof(AlembicRetortNeckEntity));
            api.RegisterBlockClass("AlembicDissolver", typeof(AlembicDissolver));
            api.RegisterBlockEntityClass("AlembicDissolverEntity", typeof(AlembicDissolverEntity));

            RecipeSystem.LoadRetortRecipes(api);
        }

        public override void StartClientSide(ICoreClientAPI api)
        {
            base.StartClientSide(api);

            /*var LiquidContainerOriginal = typeof(BlockLiquidContainerBase).GetMethod(nameof(BlockLiquidContainerBase.GetPlacedBlockInfo));
            var LiquidContainerPostfix = typeof(lavoisier_liquidcontainerfix).GetMethod(nameof(lavoisier_liquidcontainerfix.LavoisierPlacedBlockFix));

            this.harmony.Patch(LiquidContainerOriginal, postfix: new HarmonyMethod(LiquidContainerPostfix));
            */
            harmony.PatchAll();
        }
    }

    [HarmonyPatch(typeof(BlockLiquidContainerTopOpened), nameof(BlockLiquidContainerTopOpened.GetContainedInfo))]
    public class lavoisier_topopenfixContained
    {
        public static string Postfix(string __result, BlockLiquidContainerTopOpened __instance, ItemSlot inSlot)
        {
            float litres = __instance.GetCurrentLitres(inSlot.Itemstack);
            ItemStack contentStack = __instance.GetContent(inSlot.Itemstack);

            if (litres <= 0) return Lang.Get("{0} (Empty)", inSlot.Itemstack.GetName());

            string incontainername = Lang.Get(contentStack.Collectible.Code.Domain + ":incontainer-" + contentStack.Class.ToString().ToLowerInvariant() + "-" + contentStack.Collectible.Code.Path);

            if (litres == 1)
            {
                return Lang.Get("{0} ({1:G} litre of {2})", inSlot.Itemstack.GetName(), litres, incontainername);
            }

            return Lang.Get("{0} ({1:G} litres of {2})", inSlot.Itemstack.GetName(), litres, incontainername);
        }
    }

    [HarmonyPatch(typeof(BlockLiquidContainerBase), nameof(BlockLiquidContainerBase.GetContentInfo))]
    public class laviosier_liquidcontentinfofix
    {
        public static void Postfix(BlockLiquidContainerBase __instance, ItemSlot inSlot, StringBuilder dsc, IWorldAccessor world)
        {
            float litres = __instance.GetCurrentLitres(inSlot.Itemstack);
            ItemStack contentStack = __instance.GetContent(inSlot.Itemstack);

            if (litres <= 0) dsc.AppendLine(Lang.Get("Empty"));

            else
            {
                string incontainerrname = Lang.Get(contentStack.Collectible.Code.Domain + ":incontainer-" + contentStack.Class.ToString().ToLowerInvariant() + "-" + contentStack.Collectible.Code.Path);
                dsc.Replace(Lang.Get("{0} litres of {1}", litres, incontainerrname), Lang.Get("{0:G} litres of {1}", litres, incontainerrname));

                //var dummyslot = BlockLiquidContainerBase.GetContentInDummySlot(inSlot, contentStack);

                ItemSlot dummySlot;
                var pref = inSlot.Inventory?.OnAcquireTransitionSpeed;

                DummyInventory dummyInv = new DummyInventory(world.Api);
                dummySlot = new DummySlot(contentStack, dummyInv);
                dummySlot.MarkedDirty += () => { inSlot.Inventory?.DidModifyItemSlot(inSlot); return true; };

                dummyInv.OnAcquireTransitionSpeed = (transType, stack, mulByConfig) =>
                {
                    float mul = mulByConfig;
                    if (pref != null)
                    {
                        mul = pref(transType, stack, mulByConfig);
                    }

                    return mul * __instance.GetContainingTransitionModifierContained(world, inSlot, transType);
                };

                TransitionState[] states = contentStack.Collectible.UpdateAndGetTransitionStates(world, dummySlot);
                if (states != null && !dummySlot.Empty)
                {
                    bool nowSpoiling = false;
                    foreach (var state in states)
                    {
                        nowSpoiling |= __instance.AppendPerishableInfoText(dummySlot, dsc, world) > 0;
                    }
                }

            }
        }
    }


    [HarmonyPatch(typeof(BlockLiquidContainerBase), nameof(BlockLiquidContainerBase.GetPlacedBlockInfo))]
    public class lavoisier_liquidcontainerfix
    {
        
        public static string Postfix(string __result, BlockLiquidContainerBase __instance, IWorldAccessor world, BlockPos pos, IPlayer forPlayer)
        {
            float litres = __instance.GetCurrentLitres(pos);

            StringBuilder sb = new StringBuilder();
            BlockEntityContainer becontainer = world.BlockAccessor.GetBlockEntity(pos) as BlockEntityContainer;
            if (becontainer != null)
            {
                if (litres <= 0)
                {
                    sb.AppendLine(Lang.Get("Empty"));
                }
                else
                {

                    ItemSlot slot = becontainer.Inventory[__instance.GetContainerSlotId(pos)];
                    ItemStack contentStack = slot.Itemstack;

                    string incontainername = Lang.Get(contentStack.Collectible.Code.Domain + ":incontainer-" + contentStack.Class.ToString().ToLowerInvariant() + "-" + contentStack.Collectible.Code.Path);
                    sb.AppendLine(Lang.Get("Contents:"));
                    sb.AppendLine(" " + Lang.Get("{0:G} litres of {1}", litres, incontainername));
                    string perishableInfo = BlockLiquidContainerBase.PerishableInfoCompact(world.Api, slot, 0, false);
                    if (perishableInfo.Length > 2) sb.AppendLine(perishableInfo.Substring(2));
                }
            }

            StringBuilder sb2 = new StringBuilder();
            foreach (BlockBehavior bh in __instance.BlockBehaviors)
            {
                sb2.Append(bh.GetPlacedBlockInfo(world, pos, forPlayer));
            }
            if (sb2.Length > 0)
            {
                sb.AppendLine();             // Insert a blank line if there is more to add (e.g. reinforceable)
                sb.Append(sb2.ToString());
            }

            return sb.ToString();
        }
    }
}